# Minimaler Platzhalter – vollständige mDNS-Integration folgt in M3
from dataclasses import dataclass

SERVICE_TYPE = "_hhp._udp.local."

@dataclass
class Peers:
    addresses: set[tuple[str,int]]

def placeholder():
    return True
