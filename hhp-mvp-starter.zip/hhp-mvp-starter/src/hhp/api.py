from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="HHP Control API", version="1.0")

class InjectIn(BaseModel):
    semantic_tag: str
    payload: bytes

@app.post("/v1/inject")
def inject(req: InjectIn):
    # TODO: DAG insert + optional local broadcast
    return {"ok": True}

@app.get("/v1/metrics")
def metrics():
    return {"fragments_tx": 0, "fragments_rx": 0}
