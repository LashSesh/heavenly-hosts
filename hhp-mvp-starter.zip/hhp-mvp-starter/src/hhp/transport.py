# Minimaler Platzhalter – QUIC-Integration folgt in M3
async def run_quic_server(host:str, port:int, on_fragment):
    raise NotImplementedError("QUIC transport to be implemented in Milestone M3")
